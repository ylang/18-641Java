package Exception;

import java.io.Serializable;

public abstract class ExceptionHanlderAbs implements ExceptionHandler, Serializable{

	private static final long serialVersionUID = 3710192911617081852L;

}
