package Driver;

import Model.Automotive;
import Util.FileIO;

public class Controller {

	public static void main(String[] args) {
		String fileName = "car.dat";
		System.out.println("parse and create =====================");
		Automotive focus = FileIO.readFromInput("input.txt");
		focus.printInfo();
		
		System.out.println("serialize and output to file ===============");
		FileIO.serializeAutomotive(focus, fileName);

		System.out.println("deserialize and print ======================");
		Automotive anotherFocus = FileIO.deserializeAutomotive(fileName);
		if (anotherFocus != null) {
			anotherFocus.printInfo();
		}
	}
}
