package Exception;

public interface ExceptionHandler {
	public void raiseException(int exceptionNumber);
	
	public void fixException(int exceptionNumber);
}
