package Export;


public class BuildAuto extends CommAutoOpsAbs {

}
